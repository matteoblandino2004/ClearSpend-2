// ============================================================
// ClearSpend — calendar.js
// Part of the ClearSpend personal finance app.
// See README.md for full documentation and file structure.
// ============================================================

/* ================================================================
   8. CALENDAR SCREEN (Daily Tracker)
   ================================================================ */

// Draws the calendar grid for state.calYear / state.calMonth, coloring
// each day green (under budget), red (over budget), or gray (no spending),
// and outlining paydays in green.
function renderCalendar() {
  const year = state.calYear, month = state.calMonth;
  const days = new Date(year, month + 1, 0).getDate();   // total days in this month
  const firstDay = new Date(year, month, 1).getDay();    // 0 = Sunday, ... 6 = Saturday
  const dailyBudget = getDailyBudget(year, month);
  const today = new Date();
  const payDates = getPayDatesInMonth(year, month);

  // In "average" pay mode, payDates are just placeholders (not real dates),
  // so we don't want to draw payday outlines in that mode.
  const isAvgMode = state.incomeFreq !== 'monthly' && state.payMode === 'average';

  document.getElementById('cal-label').textContent =
    new Date(year, month).toLocaleString('default', { month: 'long', year: 'numeric' });

  let html = '';

  // Add empty filler cells so day 1 lines up under the correct weekday column
  for (let i = 0; i < firstDay; i++) html += '<div class="cal-day empty-day"></div>';

  let greenDays = 0, redDays = 0, totalOver = 0, totalUnder = 0;

  for (let d = 1; d <= days; d++) {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const daySpent = getDayPurchases(dateStr).reduce((s, p) => s + p.amt, 0);
    const isToday = today.getDate() === d && today.getMonth() === month && today.getFullYear() === year;
    const isPayday = !isAvgMode && payDates.includes(dateStr);

    let cls = 'none', amtHtml = '';
    if (daySpent > 0) {
      if (dailyBudget > 0 && daySpent > dailyBudget) {
        cls = 'red';
        redDays++;
        totalOver += daySpent - dailyBudget;
      } else {
        cls = 'green';
        greenDays++;
        if (dailyBudget > 0) totalUnder += dailyBudget - daySpent;
      }
      // Show a short version of the amount, e.g. $1.2k instead of $1234
      const dispAmt = daySpent >= 1000 ? '$' + (daySpent / 1000).toFixed(1) + 'k' : '$' + daySpent.toFixed(0);
      amtHtml = `<div class="day-amt">${dispAmt}</div>`;
    }

    const paydayFlag = isPayday ? '<div class="pay-flag">payday</div>' : '';
    const classes = `cal-day ${cls}${isToday ? ' today' : ''}${isPayday ? ' payday' : ''}`;
    html += `<div class="${classes}" title="${dateStr}: ${fmt(daySpent)} spent${isPayday ? ' · Payday' : ''}">${d}${amtHtml}${paydayFlag}</div>`;
  }

  document.getElementById('cal-days').innerHTML = html;

  // ---- Summary panel beside the calendar ----
  const statsEl = document.getElementById('cal-stats');
  const activeDays = greenDays + redDays;
  const monthlyIncome = getMonthlyIncome(year, month);

  let payInfo = '';
  if (state.incomeFreq !== 'monthly' && state.income > 0) {
    if (isAvgMode) {
      payInfo = `<div style="font-size:13px;color:var(--text3);margin-top:8px">Using average paycheck count (${state.incomeFreq === 'weekly' ? '4.33' : '2.17'}/mo). Switch to "pattern" or "manual" pay mode on Home for exact monthly totals.</div>`;
    } else {
      payInfo = `<div style="font-size:13px;color:var(--green);margin-top:8px">${payDates.length} paycheck${payDates.length === 1 ? '' : 's'} this month = ${fmt(monthlyIncome)} total income</div>`;
    }
  }

  statsEl.innerHTML = `
    <div class="card-title">Monthly summary</div>
    <div class="stat-grid" style="grid-template-columns:1fr 1fr;margin-bottom:16px">
      <div class="stat-card"><div class="stat-label">Under budget days</div><div class="stat-val green">${greenDays}</div></div>
      <div class="stat-card"><div class="stat-label">Over budget days</div><div class="stat-val red">${redDays}</div></div>
    </div>
    <div style="font-size:14px;color:var(--text2);margin-bottom:8px">Daily budget: <strong style="color:var(--text)">${fmt(dailyBudget)}</strong>${activeDays > 0 ? ' · ' + activeDays + ' days with spending' : ''}</div>
    ${totalOver > 0 ? `<div style="font-size:14px;color:var(--red)">Total overage this month: ${fmt(totalOver)}</div>` : ''}
    ${totalUnder > 0 ? `<div style="font-size:14px;color:var(--green)">Total saved vs budget: ${fmt(totalUnder)}</div>` : ''}
    ${payInfo}`;
}

// Moves the calendar view forward (dir = 1) or backward (dir = -1) by one month,
// rolling over to the next/previous year at the edges.
function calMove(dir) {
  state.calMonth += dir;
  if (state.calMonth > 11) { state.calMonth = 0; state.calYear++; }
  if (state.calMonth < 0)  { state.calMonth = 11; state.calYear--; }
  saveState();
  renderCalendar();
}
